----------------------------------------------
     SPUM : Soonsoon Pixel Unit Maker
	   Addon Asset
     Copyright © Soonsoon Studio
----------------------------------------------

Thanks for buying SPUM Addon 

PLEASE NOTE that SPUM Addon  can only be legally downloaded from the following 1 sources:

  1. Unity Asset Store (Standard License)

If you've obtained SPUM Addon via some other means then note that your license is effectively invalid,
as Soonsoon cannot provide support for pirated and/or potentially modified software.

All rights at Soonsoon. You can't use this asset NFTs sales. If you want to use for NFT sales, you need additional contracts are required for copyright uses.

If you have any questions, please contact to soonsoon@soonsoons.com



-----------------
 How to use
-----------------
1. This addon is basically a sprite resource pack for use with SPUM.
2. You can using Sprites in Assets/SPUM/Resources/Addons
3. If you want to custom Unit by SPUM and This Addon, You have to get SPUM from this URL.
  https://assetstore.unity.com/packages/slug/188715
4. This add-on works with SPUM version 1.7.0 or higher.
5. If you want to custom Unit by SPUM and This Addon, You have to copy this package folder to SPUM project and Re-install sprites in SPUM_Manager Object.
6. You can use Prefabs Units for you project standalone without SPUM.
   ( But this case, you can not edit or modifying custom unit with useful editor ) 
   ( We recommand using with SPUM )



-----------------
 Version History
-----------------
3.1.0
- Sample Scene Script Update.

3.0.0
- SPUM resource folder system is changed
- A few of animation bug fixed.
- In some cases, you may need to delete existing resources. For more information, please refer to SPUM’s official Git documentation.







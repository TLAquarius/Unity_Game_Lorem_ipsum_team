using UnityEngine;

// Any script using this interface MUST have an Interact() function
public interface IInteractable
{
    void Interact();
}